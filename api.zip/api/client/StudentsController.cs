﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MYMVCCoreStudentWebClient.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MYMVCCoreStudentWebClient.Controllers
{
    public class StudentsController : Controller
    {

        private List<MyStudent> students = new List<MyStudent>();
        private HttpClient httpClient = new HttpClient();
        private string url = "";


        public StudentsController()
        {
            url = @"https://localhost:44396/api/StudentsApi";
            httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

        // GET: StudentsController
        [HttpGet]
        public async Task<ActionResult> Index(string studentName)
        {

            if (String.IsNullOrEmpty(studentName))
            {
                var msg = await httpClient.GetAsync(url);
                var studentResponse = msg.Content.ReadAsStringAsync();

                students = JsonConvert.DeserializeObject<List<MyStudent>>(studentResponse.Result);

                return View(students);
            }
            else
            {
                var msg = await httpClient.GetAsync(url + "?studentName=" + studentName);
                var studentResponse = msg.Content.ReadAsStringAsync();

                students = JsonConvert.DeserializeObject<List<MyStudent>>(studentResponse.Result);

                return View(students);
            }

        }


        // GET: StudentsController/Details/5
        public async Task<ActionResult> Details(int id)
        {
            var msg = await httpClient.GetAsync(url + "/" + id);
            var studentResponse = msg.Content.ReadAsStringAsync();

            MyStudent myStudent = JsonConvert.DeserializeObject<MyStudent>(studentResponse.Result);

            return View(myStudent);
        }

        // GET: StudentsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StudentsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(MyStudent newStudent)
        {
            try
            {
                StringContent studentContent = new StringContent(
                    JsonConvert.SerializeObject(newStudent), Encoding.UTF8, "application/json");

                var msg = await httpClient.PostAsync(url, studentContent);
                var studentResponse = msg.Content.ReadAsStringAsync();

                if (studentResponse.Result.Contains("conflict"))
                {
                    return RedirectToAction(nameof(Create));
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentsController/Edit/5
        public async Task<ActionResult> Edit(int id)
        {

            var msg = await httpClient.GetAsync(url + "/" + id);
            var studentResponse = msg.Content.ReadAsStringAsync();

            MyStudent myStudent = JsonConvert.DeserializeObject<MyStudent>(studentResponse.Result);

            return View(myStudent);
        }

        // POST: StudentsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, MyStudent studentToUpdate)
        {
            try
            {
                StringContent studentContent = new StringContent(JsonConvert.SerializeObject(studentToUpdate), Encoding.UTF8, "application/json");

                var msg = await httpClient.PutAsync(url + "/" + id, studentContent);
                var studentResponse = msg.Content.ReadAsStringAsync();

                if (studentResponse.Status == TaskStatus.Faulted)
                {
                    return RedirectToAction(nameof(Edit));
                }

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentsController/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            var msg = await httpClient.GetAsync(url + "/" + id);
            var studentResponse = msg.Content.ReadAsStringAsync();

            MyStudent myStudent = JsonConvert.DeserializeObject<MyStudent>(studentResponse.Result);

            return View(myStudent);
        }

        // POST: StudentsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, MyStudent studentToDelete)
        {
            try
            {
                var msg = await httpClient.DeleteAsync(url + "/" + id);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
